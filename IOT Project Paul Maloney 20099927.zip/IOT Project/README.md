# EnergyMate
#### Student Name: *Paul Maloney*   Student ID: *20099927*

The project aim is to have a system where smart devices are recorded for how long they are running and then this data is taken and put in to a built website to calculate how much the devices are costing per session use for easy access to help users to better manage their energy costs. 

## Tools, Technologies and Equipment

Rasberry Pi
Smart plugs
Smart bulbs
PS5 
Glitch
ThingSpeak
Insomnia

## Known bugs/problems:
The programes are not sending the correct information to each other and following the process as planned. The rasberry pi is not able to recognise when the necessary devices are not running and save the time to send on to Thingspeak. The steps have to be hard coded in to show it working. The JSON data is also not updating correctly to add to the website. 

Any sources referred to during the development of the assignment:
https://www.w3schools.com/default.asp  build the code to upload data to Thingspeak and to scan and declare the IP addresses that are on the LAN

## Project Repository
https://github.com/Paulmal21/NetworkingProject22.git
