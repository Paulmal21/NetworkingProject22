import webbrowser as wb


id = "1"
appliance = "VIDEO EXAMPLE"
usage = "250"
duration = "45"


link = "https://api.thingspeak.com/update?api_key=KSE0AQW60KUQX4EH&field1=" + id + "&field2=" + appliance + "&field3=" + usage + "&field4=" + duration + " &field5=0.4327"

wb.open(link)