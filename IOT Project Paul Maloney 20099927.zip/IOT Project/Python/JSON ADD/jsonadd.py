import json

filename = 'property-hub.json'
entry = {"id": "200"
         "appliance": "Microwave"
         "usage": 230
         "duration": 200
         "rate": 0.4327
         "id": "200"
         }

# 1. Read file content
with open(filename, "r") as file:
    data = json.load(file)

# 2. Update Json object
data.append(entry)

# 3. Write Json file
with open(filename, "w") as file
    json.dump(data,file)