# Python program to update
# JSON


import json

# JSON data:
x =     { "id": "200",
        "appliance": "Smart Bulb",
        "usage": "60",
        "duration": "30",
        "rate": "0.4327"}

# python object to be appended
y = {"propertylist"}

# parsing JSON string:
z = json.loads(x)

# appending the data
z.update(y)

# the result is a JSON string:
print(json.dumps(z))