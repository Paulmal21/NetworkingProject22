import http.client

conn = http.client.HTTPSConnection("thingspeak.com")

payload = ""

headers = {
    'cookie': "_thingspeak_s_id=a04edfad02a31440dd5ecf7f0da74e53",
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
    'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    'Accept-Language': "en-US,en;q=0.5",
    'Accept-Encoding': "gzip, deflate, br",
    'Referer': "https://thingspeak.com/channels/1990838/private_show",
    'Connection': "keep-alive",
    'Cookie': "AMCV_B1441C8B533095C00A490D4D%40AdobeOrg=-408604571%7CMCIDTS%7C19349%7CMCMID%7C19100392110287931840573478755075794861%7CMCAID%7CNONE%7CMCOPTOUT-1671801274s%7CNONE%7CMCAAMLH-1672398874%7C6%7CMCAAMB-1672398874%7Cj8Odv6LonN4r3an7LhD3WZrU1bUpAkFkkiY1ncBR96t2PTI%7CvVersion%7C4.6.0; s_ecid=MCMID%7C19100392110287931840573478755075794861; ki_t=1671393687091%3B1671794074808%3B1671794117906%3B3%3B48; ki_r=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8%3D; page_count=MTA%3D--2fc696c9690681af2c1dab4150ba4cc0c9312881; AMCVS_B1441C8B533095C00A490D4D%40AdobeOrg=1; s_cc=true; s_sq=maththingspeak%3D%2526c.%2526a.%2526activitymap.%2526page%253Dthingspeak.com%25252Fchannels%25252F1990838%25252Fprivate_show%2526link%253DJSON%2526region%253Ddevinfo_modal%2526pageIDType%253D1%2526.activitymap%2526.a%2526.c%2526pid%253Dthingspeak.com%25252Fchannels%25252F1990838%25252Fprivate_show%2526pidt%253D1%2526oid%253Dhttps%25253A%25252F%25252Fthingspeak.com%25252Fchannels%25252F1990838%25252Ffeed.json%2526ot%253DA; _thingspeak_s_id=a04edfad02a31440dd5ecf7f0da74e53; mwa_SID=RMlzWM",
    'Upgrade-Insecure-Requests': "1",
    'Sec-Fetch-Dest': "document",
    'Sec-Fetch-Mode': "navigate",
    'Sec-Fetch-Site': "same-origin",
    'Sec-Fetch-User': "?1",
    'If-None-Match': "W/b49322e04c63d7d1b71c8232467d11ea"
    }

conn.request("GET", "/channels/1990838/feed.json", payload, headers)

res = conn.getresponse()
data = res.read()

print(data.decode("utf-8"))